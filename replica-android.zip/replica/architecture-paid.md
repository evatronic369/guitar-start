# Architecture: your guitar-from-scratch app (a rebuild of Yousician's beginner loop)

Built from `recon.md` and `features.csv`. SQL is in `schema.sql` (not run against a live Postgres yet, see the end).
Assumed because you have not said otherwise: Android only, solo or very small team, no existing stack.

## Stack

| layer | choice | why |
| --- | --- | --- |
| app | Kotlin + Jetpack Compose (Android) | the hard part is real-time mic audio; a native app talks to the audio stack directly. Expo would need a custom native audio module anyway, so it saves little here. Swap to Expo only if you already know React Native or want iOS soon |
| audio capture | Oboe (low-latency capture) with `AudioRecord` as fallback | lowest latency on most phones; turn off echo and noise processing for the guitar signal |
| pitch detection | your own YIN or McLeod pitch method, in Kotlin or C++ | both are short, well documented algorithms. Check licences before pulling a library in: TarsosDSP is GPL, which is a problem for a closed app |
| database | Postgres on Supabase | one database, row level security, free at zero users |
| auth | Supabase Auth, email plus Google sign-in | Google sign-in on Android is one token exchange |
| payments | Google Play Billing | Play requires it for in-app digital subscriptions. Stripe is not an option inside the app |
| server logic | Supabase Edge Functions | verify purchases, sign video URLs, receive Google notifications. No separate server |
| email | Resend | weekly report, nothing else yet |
| jobs | Supabase `pg_cron` calling Edge Functions | keeps jobs next to the data |
| files | Supabase Storage (private bucket, signed URLs) | lesson videos. Move to Cloudflare R2 if bandwidth cost bites |
| hosting | none for the app; Google Play for distribution | a landing page comes later with `/replica-launch` |

One database, no microservices, no web app.

## Schema

Tables: 11 (profiles, levels, missions, songs, song_charts, tasks, attempts, task_progress, daily_usage, subscriptions, play_notifications).
Access rules: Postgres row level security. Clients can read through the policies; they write only through four functions
(`add_play_time`, `submit_attempt`, plus profile edits on 7 allowed columns). Full SQL: `schema.sql`.

Where the paywall lives: **in the database, not the app.** `missions.is_free` decides which missions free users can open.
Policies hide the `tasks` rows of locked missions and the `song_charts` of premium songs, so a modified app cannot read them.
The free daily cap is enforced the same way: a free user with zero seconds left gets no chart back.

Changes from the recon model, and why:
- `Progress` per mission became `task_progress` per task. Mission progress is counted from it (`mission_progress()`), so there is one source of truth.
- `Usage` and `Activity` merged into `daily_usage`, keyed by the user's local date.
- `Song.chart` moved to its own table so a locked song can still appear in the list.
- No `trial_used` column. Google Play decides trial eligibility itself.
- Family plan is not in the schema (it needs a household table). It is a `could` in the matrix.

## API

Almost everything is the Supabase client talking to PostgREST under the policies above. Anything marked `fn` is an Edge Function.

| # | method path | does | who | input | output | flow |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | POST /auth/v1/signup, /token | email sign-up and sign-in | public | email, password | session | F01 |
| 2 | Auth signInWithIdToken (Google) | Google sign-in | public | Google ID token | session | F01 |
| 3 | PATCH /rest/v1/profiles?id=eq.{me} | save instrument, level, guitar type, tuning, timezone, latency | owner | 7 columns | profile | F01 |
| 4 | GET /rest/v1/levels, /missions | the learning path (locked ones still listed) | signed in | none | rows | F01 F02 |
| 5 | POST /rest/v1/rpc/mission_progress | tasks done and stars per mission, no locked content | signed in | none | counts | F01 F02 |
| 6 | GET /rest/v1/tasks?mission_id=eq.{id} | tasks of a mission; empty if mission is locked | signed in | mission id | rows | F01 F02 |
| 7 | POST /functions/v1/video-url (fn) | signed URL for a lesson video after an unlock check | signed in | task id | URL, expiry | F01 |
| 8 | GET /rest/v1/song_charts?song_id=eq.{id} | the chart; empty if locked or daily time used up | signed in | song id | chart json | F01 F04 |
| 9 | POST /rest/v1/rpc/add_play_time | heartbeat every 15 s while playing | owner | seconds, notes | seconds left (null = unlimited) | F02 |
| 10 | POST /rest/v1/rpc/submit_attempt | save a result; stars computed on the server; safe to retry | owner | task, attempt uuid, score, accuracy, duration | stars, completed | F01 F04 |
| 11 | POST /rest/v1/rpc/my_entitlement | tier, status, period end, seconds left | owner | none | one row | F02 F03 |
| 12 | GET /rest/v1/songs?or=(title.ilike.*q*,artist.ilike.*q*) | song search, lock flag via `is_premium` | signed in | text | rows | F04 |
| 13 | GET /rest/v1/songs?id=eq.{id} | song detail | signed in | id | row | F04 |
| 14 | GET /rest/v1/daily_usage?order=usage_date.desc&limit=60 | progress screen and streak (streak computed on the phone) | owner | none | rows | F05 |
| 15 | GET /rest/v1/task_progress | level completion and certificates | owner | none | rows | F01 |
| 16 | POST /functions/v1/play-verify (fn) | verify a purchase token with the Google Play Developer API, upsert subscription, acknowledge it | owner | product id, purchase token | entitlement | F03 |
| 17 | POST /functions/v1/delete-account (fn) | delete the user and cascade their rows | owner | none | 204 | account |
| 18 | POST /functions/v1/play-rtdn (fn) | webhook from Google | Google only | Pub/Sub push body | 204 | F03 |

Webhooks in: Google Play real-time developer notifications (Pub/Sub push to route 18; check the push token, dedupe on `message_id`).
Webhooks out: none.
Official APIs only: Google Play Developer API and Play Billing with your own developer account and keys.

Jobs:
| name | schedule | what it does |
| --- | --- | --- |
| weekly-report | hourly | emails users whose local time is Monday morning and `last_report_sent_on` is not today; sets it |
| sync-subscriptions | daily | re-checks subscriptions ending in 2 days or on hold with the Play API, in case a notification was missed |
| purge-notifications | daily | deletes `play_notifications` older than 30 days |

## The parts that bite

- **Real-time audio:** the riskiest thing in the whole project. Single notes are a solved problem (YIN or McLeod); chords are not,
  and need a different approach (chroma features) that is much less accurate. Start with single notes and decide how you handle chords
  after you have tried it on real phones. Phone mics, built-in noise suppression and Bluetooth headsets all change the signal.
- **Latency and timing:** hit/miss depends on knowing how late the audio arrives. Build a short calibration step (`profiles.audio_latency_ms`).
- **Device spread:** the same code behaves differently on a cheap phone and a flagship. Test on at least three phones before building more.
- **Time zones:** "today" for the daily cap is the user's local date, so the timezone is stored and validated. Daylight saving is handled by Postgres.
- **Idempotency:** Google notifications arrive twice (`message_id` is unique); attempts retry from a flaky connection (`client_attempt_id` is unique).
  A retried heartbeat can double count a few seconds, which is accepted.
- **Races:** `add_play_time` is one upsert, so two phones playing at once cannot lose time.
- **Paywall bypass:** a modified app cannot read locked tasks or charts, because the database refuses. The remaining holes are
  charts already cached on the phone and offline play. Decide whether offline free play counts toward the cap; the simplest rule is that it does not exist.
- **Trusting the phone:** accuracy is computed on-device and sent up, so a determined user can fake a score. That only hurts their own stars;
  it is fine unless you add leaderboards.
- **Play Billing:** acknowledge every purchase within 3 days or Google refunds it; handle grace period, on-hold, refunds (`revoked`) and
  upgrades (a new purchase token replaces the old one). Test with licence testers before real money.
- **Content rule:** a free mission must only point at non-premium songs, or free users will hit a locked chart inside a free lesson. Check this when seeding.
- **Content is the real bulk:** the engine is weeks, the lessons and charts are months. You need an authoring tool or at least a JSON format and a script.
  Songs must be your own, public domain or properly licensed.
- **GDPR deletion:** everything cascades from `profiles`, which cascades from `auth.users`. Videos are shared, so nothing per-user lives in Storage.
- **Rate limits:** the heartbeat is 4 calls a minute per player; Supabase's free tier is fine for development, check the limits before launch.

## Build order

0. **Audio spike (no backend).** One screen: mic in, single-note detection, a target note, right/wrong shown. Done when a slow melody scores correctly on three different phones. If this fails, nothing else matters.
1. **Vertical slice.** Screens S01 (email only), S03, S05 (plain list), S08, S09.
   Tables: profiles, levels, missions, songs, song_charts, tasks, attempts, task_progress. Routes: 1, 3, 4, 6, 8, 10.
   Seed one level with one free mission of 3 song tasks. Sign up, play, see stars, close the app, reopen, progress is still there.
2. **Must-haves.** S02, S04, S12 (tuner), full S05 to S07, S15, S16, S17, S18.
   Tables: daily_usage, subscriptions, play_notifications. Routes: 2, 5, 7, 9, 11, 16, 17, 18.
   This is where the wall goes in: the cap, locked missions, the paywall and Play Billing.
3. **Should-haves.** S10, S11, S13; chord and strumming trainers; unlock-next-level rule; the 7-day trial offer (configured in Play Console); restore purchases. Routes: 12, 13, 14.
4. **Could-haves.** Weekly report email job, certificates (S14, route 15), practice reminders, ear training, family plan.
5. **Fixes from replica-entrepreneur,** once it has run.

## Not yet checked

- `schema.sql` has not been run: there is no Postgres in this workspace. Run it once in a fresh Supabase project (SQL editor) and tell me any errors.
- Free-tier numbers (daily minutes, which missions are free) are your decisions, not facts about the original.
