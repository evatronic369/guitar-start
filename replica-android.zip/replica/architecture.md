# Architecture (ALL-FREE version): guitar-from-scratch app, Android

Supersedes the paid plan, which is kept as `architecture-paid.md` and `schema-paid.sql`. Everything is free, so there are no
subscriptions, no paywall, no daily cap, no Play Billing.

## What was removed
Tables `subscriptions` and `play_notifications`; columns `is_free` and `is_premium`; the `song_charts` split (the chart is now a column on `songs`);
the entitlement and cap functions; routes `play-verify`, `play-rtdn`, `my_entitlement`, `video-url`; jobs `sync-subscriptions` and `purge-notifications`;
screens S15 (limit reached), S16 (paywall) and S17 (purchase sheet). Recon rows for these are marked `skip` in `features.csv`.

## Stack
| layer | choice | why |
| --- | --- | --- |
| app | Kotlin + Jetpack Compose | real-time mic audio needs the native audio stack |
| audio | `AudioRecord` now (Oboe later if latency needs it) + my own YIN pitch detector | no GPL libraries |
| database / auth / files / functions | Supabase | one managed backend |
| email | Resend (only for the optional weekly report) | |
No web app, no payments, no webhooks.

## Schema
9 tables: profiles, levels, missions, songs, tasks, attempts, task_progress, daily_usage. Row level security; content is readable by any signed-in user;
users read only their own progress; writes go only through `add_play_time`, `submit_attempt` and profile edits. See `schema.sql`.

## API (12 routes, 0 webhooks)
1 sign up and sign in (email) · 2 Google sign-in · 3 PATCH profiles · 4 GET levels and missions · 5 rpc mission_progress · 6 GET tasks ·
7 GET songs (chart included) · 8 rpc add_play_time (stats) · 9 rpc submit_attempt · 10 GET task_progress · 11 GET daily_usage · 12 fn delete-account.
Job (optional): weekly-report, hourly, emails users on their local Monday morning.

## The parts that bite
- **Real-time audio** is still the riskiest part. Single notes only for now; chords are a separate, harder problem.
- **Content** is the real bulk of the work: your own lessons and charts, or public-domain songs.
- **Running costs without revenue:** video bandwidth and database size are paid by you. Keep videos short and few until you know usage.
- **Trusting the phone:** accuracy is computed on-device; fine until you add leaderboards.
- **Idempotency:** `client_attempt_id` makes retried attempts safe. **Time zones:** the stats date is the user's local date.

## Build order
0. Audio spike: mic, YIN, target note, right/wrong. Done when it works on three phones.  **(code written, untested, see build-log.md)**
1. Vertical slice: path list, play screen, result, stars. Fake data layer first, same signatures as the real one.
2. Backend swap-in (`/replica-backend`): auth, the 9 tables, real repository.
3. Remaining screens: onboarding, setup, tuner, videos, song search, progress.
4. Could-haves, then fixes from `/replica-entrepreneur`.
