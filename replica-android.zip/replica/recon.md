# Recon map: Yousician, guitar (Android)

Scope: the beginner guitar loop (Basics to about level 5), plus the free-to-paid boundary
For: not yet confirmed (assumed: your own product, a guitar-from-scratch app)
Date: 2026-10-26

## How this was made

Public sources only. I have not seen the Android app itself, so every screen below is inferred from
help articles, store listings, reviews and press. Nothing was installed, logged into or bypassed.
Confidence: H = stated in a source, M = implied by several, G = guess.
To fill the gaps, you drive your own account while I read along (Step "Next" at the bottom).

## Sources

| # | source | URL | notes |
| --- | --- | --- | --- |
| 1 | help: guitar learning path | https://support.yousician.com/hc/en-us/articles/206930639-How-the-guitar-learning-path-works | missions, themes, 10 levels, activity report |
| 2 | help: premium options | https://support.yousician.com/hc/en-us/articles/115005189525-Premium-options-available-in-Yousician | what each tier unlocks, Google Play billing |
| 3 | marketing: pricing and trial | https://yousician.com/lp/ukulele-us | 7-day trial, Premium+ $11.66/mo billed $139.99/yr (varies by region and date) |
| 4 | family plan | https://yousician.com/family | 4 accounts, 7-day trial |
| 5 | App Store listing | https://appshunter.io/ios/app/yousician/id959883039 | One Instrument $19.99/month; mirrors the Android feature set |
| 6 | review: Common Sense Media | https://www.commonsensemedia.org/app-reviews/yousician-your-personal-music-teacher | free tier has few recognisable songs early on |
| 7 | review: Guitar World | https://www.guitarworld.com/artists/yousician-fast-fun-way-learn-play-guitar-video | Missions run from real basics to funk strumming and muting |
| 8 | review: American Songwriter | https://americansongwriter.com/yousician-review/ | Learn tab, Missions, mic permission |
| 9 | user review (Sensor Tower) | https://app.sensortower.com/api/ios/apps/959883039?country=US | "gave me just enough to get started, then cut me off" |
| 10 | Internet Matters | https://www.internetmatters.org/advice/apps-and-platforms/skills-building/yousician | free: daily time cap, selected lessons and songs only |

## Core loop

Play along with a scrolling tab or notation on your real guitar, the phone mic scores each note in
real time, and finishing a mission's tasks moves you up the learning path.

## The paywall (your question)

What the public sources agree on:
- Free tier: a daily playtime cap, plus only selected lessons and songs (sources 6, 9, 10).
- Premium: unlimited lesson time and all popular songs, one instrument. Premium+: all five instruments (source 2).
- A 7-day free trial of Premium+ is offered, and the app asks you to subscribe after the early lessons (sources 3, 9).
- Android buys go through Google Play and are managed there (source 2).

What I could not confirm: the exact mission or level where the wall appears, and today's daily-minutes figure
(one older article said 20 minutes of feedback a day, treat it as dated). The wall may also be a mix of the time cap and
locked missions. Only your own free account can show this. Play until the app stops you, screenshot each screen,
and do not work around the block.

## Screens

| ID | screen | how to reach | purpose | key components | states seen | conf |
| --- | --- | --- | --- | --- | --- | --- |
| S01 | Welcome / sign-up | first launch | create or log in to an account | email, Google sign-in, terms | empty, error | M |
| S02 | Instrument and goal pick | after S01 | choose guitar, skill level | option cards | default | M |
| S03 | Mic permission | first play | allow microphone | system dialog, explainer | granted, denied | H |
| S04 | Guitar setup | first play, settings | acoustic vs electric, tuning | choice cards, tuner | default | H (help: "Choosing your setup") |
| S05 | Learn / Missions home | Learn tab | the path: levels, themes, missions | level list, theme tabs, mission cards, lock icons | filled, locked | H |
| S06 | Mission detail | tap mission | list of tasks (songs, videos, trainers) | task list, progress, stars | partly done, complete, locked | H |
| S07 | Video tutorial | task in mission | teach a skill | video player, continue | playing | H |
| S08 | Play screen | song or trainer task | scrolling tab, mic scores notes | tab lane, note targets, score, pause | listening, hit, miss, paused | H |
| S09 | Results | end of S08 | score, stars, retry or next | stars, accuracy, next button | pass, fail | M |
| S10 | Songs library and search | Songs tab | find a song | search bar, filters, song rows, lock icons | empty, results, locked | H |
| S11 | Song detail | tap song | difficulty, start | cover, difficulty, play | free, locked | M |
| S12 | Tuner | Tools or setup | tune the guitar | pitch meter, string selector | listening, in tune | M |
| S13 | Progress / activity | profile area | notes played, time, streak | charts, streak, weekly goal | empty, filled | H (weekly report) |
| S14 | Level certificate | finish a level | reward | certificate card, share | shown | H (help article) |
| S15 | Daily limit reached | free play after cap | tell user time is up | message, upgrade button | shown | M |
| S16 | Paywall / trial offer | S15, locked mission, locked song | sell Premium or Premium+ | plan cards, trial button, price, restore | monthly, yearly | H |
| S17 | Google Play purchase sheet | S16 | pay | system sheet | confirm, cancelled, failed | H |
| S18 | Profile and settings | profile icon | account, subscription, notifications | list rows, manage subscription link | default | M |

## Flows

```
F01 Install to first lesson
    S01 -> S02 -> S04 -> S03 -> S05 -> S06 -> S07 -> S08 -> S09
    happy path clicks: about 9 (inferred)
    edge: mic denied, noisy room, wrong tuning, no sign-in

F02 Free user hits the wall
    S08 -> S09 -> S05/S06 (locked mission) -> S16
    or S08 -> S15 -> S16
    edge: daily cap mid-song, locked song from search, offline

F03 Start the trial and subscribe
    S16 -> S17 -> S05 (everything unlocked)
    edge: payment cancelled, trial already used, cancel before day 7 (via Google Play)

F04 Find and play a song
    S10 -> S11 -> S08 -> S09
    edge: song locked, no results

F05 Weekly report
    server job -> email on Mondays -> S13
```

## Components

| component | variants | states | used on |
| --- | --- | --- | --- |
| Button | primary, secondary, text | default, pressed, disabled, loading | all |
| Mission card | level, theme tag | locked, in progress, done | S05, S06 |
| Task row | song, video, trainer | locked, new, starred | S06 |
| Tab/notation lane | scrolling, chord chart | idle, playing, paused | S08 |
| Note target and feedback | hit, miss, early, late | per note | S08 |
| Star rating | 0 to 3 | static, animating | S06, S09 |
| Plan card | monthly, yearly, family | selected, best value | S16 |
| Lock badge | on mission, song | shown | S05, S06, S10 |
| Tuner meter | needle | flat, in tune, sharp | S12 |
| Bottom nav | Learn, Songs, Profile | active | S05, S10, S13 |

## Inferred data model

```
User         id, email, auth_provider, created_at, subscription_status, trial_used
             evidence: S01, S16, help premium article    confidence: high

Subscription user_id, tier (premium | premium_plus | family), source (google_play | web | apple), expires_at
             evidence: source 2, S16/S17               confidence: high

Level        id, number (1-10), theme
Mission      id, level_id, title, theme, is_free
Task         id, mission_id, type (song | video | trainer), content_id, order
             evidence: help learning-path article       confidence: high (is_free is a guess)

Song         id, title, artist, difficulty, is_original, is_premium, chart (notes, timing)
             evidence: S10, help article                confidence: medium

Attempt      user_id, task_id, score, stars, accuracy, played_at, duration_s
             evidence: S09, S13, weekly report          confidence: medium

Progress     user_id, mission_id, tasks_done, stars
Activity     user_id, date, play_seconds, notes_played, streak
             evidence: Monday activity report           confidence: high
Usage        user_id, date, seconds_played   (drives the daily cap)    confidence: guess
```

Relationships: Level 1-n Mission, Mission 1-n Task, Task n-1 Song or Video, User 1-n Attempt, User 1-n Progress, User 1-1 Subscription.

## Feature matrix

See `features.csv`.

## Out of scope (cannot or should not be cloned)

- The licensed popular-song catalogue and charts (publishing licences)
- Yousician's original lesson videos, songs, mission wording and artwork
- Its name, logo, voice and level and theme naming
- Its user base and the David Bowie style artist partnerships
- The GuitarTuna sister app

## Size

Screens 18, flows 5, entities 9.
Hard parts: real-time pitch and chord detection on Android with low latency across many phones and mics,
note-timing scoring, the scrolling tab renderer, authoring the lesson content (the real bulk), Google Play Billing with trials,
the free-tier cap and lock rules.
Size: L for the engine plus a Basics-to-level-3 path. XL if you want a whole 10-level library.

## Next

1. You play a free account up to the wall and send screenshots into `replica/screens/` (tell me where it stopped).
2. Then `/replica-architect`.
