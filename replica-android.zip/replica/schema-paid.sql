-- replica/schema.sql
-- Guitar-from-scratch app (rebuild of the core loop mapped in recon.md). Postgres on Supabase.
-- Access rules: row level security. Clients read through RLS and write ONLY through the rpc functions below.
-- Deviations from the "id uuid default gen_random_uuid()" rule, on purpose:
--   profiles.id = auth.users.id; song_charts.song_id is a 1-1 key; task_progress and daily_usage use composite keys.

create extension if not exists pg_trgm with schema extensions;

create function public.set_updated_at() returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

-- ───────────── tables ─────────────

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  instrument text not null default 'guitar' check (instrument in ('guitar')),
  skill_level text check (skill_level in ('beginner','some_experience','advanced')),
  guitar_type text check (guitar_type in ('acoustic','electric')),
  tuning text not null default 'EADGBE',
  timezone text not null default 'UTC',            -- IANA name; decides what "today" means for the daily cap
  audio_latency_ms int not null default 0 check (audio_latency_ms between 0 and 1000),
  last_report_sent_on date,                         -- weekly report job bookkeeping
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.levels (
  id uuid primary key default gen_random_uuid(),
  number smallint not null unique check (number between 1 and 10),
  title text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.missions (
  id uuid primary key default gen_random_uuid(),
  level_id uuid not null references public.levels(id) on delete restrict,
  theme text not null check (theme in ('melody','chords','knowledge')),
  title text not null,
  position smallint not null,
  is_free boolean not null default false,           -- THE wall: free users only get is_free missions
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (level_id, theme, position)
);
create index on public.missions (level_id);

create table public.songs (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  artist text not null default '',
  license text not null check (license in ('original','public_domain','licensed')),
  difficulty smallint not null check (difficulty between 1 and 10),
  bpm smallint not null check (bpm between 30 and 300),
  is_premium boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index on public.songs (difficulty);
create index songs_search_idx on public.songs
  using gin (lower(title || ' ' || artist) extensions.gin_trgm_ops);

-- The chart (notes, timing) lives apart from the song row so RLS can hide it from free users
-- while the song still shows in the list with a lock badge.
create table public.song_charts (
  song_id uuid primary key references public.songs(id) on delete cascade,
  format_version smallint not null default 1,
  chart jsonb not null,                              -- [{t_ms, dur_ms, string, fret, midi}] or chord events
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.tasks (
  id uuid primary key default gen_random_uuid(),
  mission_id uuid not null references public.missions(id) on delete cascade,
  position smallint not null,
  type text not null check (type in ('song','video','trainer')),
  song_id uuid references public.songs(id) on delete restrict,
  video_path text,                                   -- storage path, served by signed URL only
  trainer_config jsonb,
  pass_accuracy numeric(3,2) not null default 0.70 check (pass_accuracy between 0 and 1),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (mission_id, position),
  constraint task_shape check (
    (type = 'song'    and song_id is not null) or
    (type = 'video'   and video_path is not null) or
    (type = 'trainer' and trainer_config is not null)
  )
);
create index on public.tasks (song_id);

create table public.attempts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  task_id uuid not null references public.tasks(id) on delete cascade,
  client_attempt_id uuid not null,                   -- idempotency key, so offline retries never double count
  score int not null check (score >= 0),
  stars smallint not null check (stars between 0 and 3),
  accuracy numeric(5,4) not null check (accuracy between 0 and 1),
  duration_s int not null check (duration_s between 0 and 3600),
  notes_played int not null default 0 check (notes_played >= 0),
  played_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (user_id, client_attempt_id)
);
create index on public.attempts (user_id, played_at desc);
create index on public.attempts (task_id);

create table public.task_progress (
  user_id uuid not null references public.profiles(id) on delete cascade,
  task_id uuid not null references public.tasks(id) on delete cascade,
  best_stars smallint not null check (best_stars between 0 and 3),
  best_accuracy numeric(5,4) not null check (best_accuracy between 0 and 1),
  completed_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  primary key (user_id, task_id)
);
create index on public.task_progress (task_id);

create table public.daily_usage (
  user_id uuid not null references public.profiles(id) on delete cascade,
  usage_date date not null,                          -- the USER'S local date (profiles.timezone)
  play_seconds int not null default 0 check (play_seconds >= 0),
  notes_played int not null default 0 check (notes_played >= 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  primary key (user_id, usage_date)
);

create table public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  tier text not null check (tier in ('premium','premium_plus')),
  product_id text not null,
  purchase_token text not null unique,               -- Google Play token; one row per purchase
  status text not null check (status in ('trialing','active','grace','canceled','on_hold','expired','revoked')),
  current_period_end timestamptz not null,
  auto_renewing boolean not null default true,
  acknowledged boolean not null default false,       -- Play refunds unacknowledged purchases after about 3 days
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index on public.subscriptions (user_id, status);

-- Google real-time developer notifications arrive more than once. message_id makes handling idempotent.
create table public.play_notifications (
  id uuid primary key default gen_random_uuid(),
  message_id text not null unique,
  payload jsonb not null,
  received_at timestamptz not null default now(),
  processed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- updated_at triggers
do $$
declare t text;
begin
  foreach t in array array['profiles','levels','missions','songs','song_charts','tasks','attempts',
                           'task_progress','daily_usage','subscriptions','play_notifications']
  loop
    execute format('create trigger set_updated_at before update on public.%I
                    for each row execute function public.set_updated_at()', t);
  end loop;
end $$;

-- new auth user -> profile row
create function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id) values (new.id) on conflict do nothing;
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- reject bad time zone names (a bad one would break every "today" calculation)
create function public.validate_timezone() returns trigger language plpgsql as $$
begin
  if not exists (select 1 from pg_timezone_names where name = new.timezone) then
    raise exception 'invalid timezone: %', new.timezone;
  end if;
  return new;
end $$;
create trigger validate_timezone before insert or update of timezone on public.profiles
  for each row execute function public.validate_timezone();

-- ───────────── entitlement and the daily cap ─────────────
-- Internal helpers take a uid and are NOT callable by clients (see revokes below).

create function public._has_premium(uid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.subscriptions s
    where s.user_id = uid
      and s.status in ('trialing','active','grace','canceled')   -- canceled = auto-renew off, access until period end
      and s.current_period_end > now()
  )
$$;

create function public._local_today(uid uuid) returns date
language sql stable security definer set search_path = public as $$
  select (now() at time zone p.timezone)::date from public.profiles p where p.id = uid
$$;

-- DECIDE YOUR OWN NUMBER. The original's cap is not confirmed; this is a placeholder (20 minutes).
create function public.free_daily_seconds() returns int language sql immutable as $$ select 1200 $$;

create function public._can_access_task(uid uuid, p_task uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.tasks t join public.missions m on m.id = t.mission_id
    where t.id = p_task and (m.is_free or public._has_premium(uid))
  )
$$;

-- No-arg versions use auth.uid() and are safe for clients and for RLS policies.
create function public.has_premium() returns boolean
language sql stable security definer set search_path = public as $$
  select public._has_premium(auth.uid())
$$;

-- null means unlimited (premium)
create function public.seconds_left_today() returns int
language sql stable security definer set search_path = public as $$
  select case when public._has_premium(auth.uid()) then null
    else greatest(0, public.free_daily_seconds() - coalesce(
      (select u.play_seconds from public.daily_usage u
        where u.user_id = auth.uid() and u.usage_date = public._local_today(auth.uid())), 0))
  end
$$;

-- ───────────── RPCs: the only write path for clients ─────────────

-- Heartbeat while a play screen is open (client sends 15 s at a time). Single upsert, so concurrent calls cannot lose time.
create function public.add_play_time(p_seconds int, p_notes int default 0) returns int
language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid();
begin
  if uid is null then raise exception 'not authenticated' using errcode = '28000'; end if;
  if p_seconds < 0 or p_seconds > 60 then raise exception 'bad seconds'; end if;
  insert into public.daily_usage as u (user_id, usage_date, play_seconds, notes_played)
  values (uid, public._local_today(uid), p_seconds, greatest(p_notes, 0))
  on conflict (user_id, usage_date) do update
    set play_seconds = u.play_seconds + excluded.play_seconds,
        notes_played = u.notes_played + excluded.notes_played;
  return public.seconds_left_today();
end $$;

-- Stars are computed here, not by the client. The accuracy itself comes from the phone (audio is analysed on-device).
create function public.submit_attempt(
  p_task_id uuid, p_client_attempt_id uuid, p_score int, p_accuracy numeric,
  p_duration_s int, p_notes int default 0
) returns table (out_stars smallint, out_completed boolean)
language plpgsql security definer set search_path = public as $$
declare
  uid uuid := auth.uid();
  v_pass numeric;
  v_stars smallint;
  v_new uuid;
begin
  if uid is null then raise exception 'not authenticated' using errcode = '28000'; end if;
  if not public._can_access_task(uid, p_task_id) then
    raise exception 'locked' using errcode = '42501';
  end if;
  select pass_accuracy into v_pass from public.tasks where id = p_task_id;
  v_stars := case when p_accuracy < v_pass then 0
                  else 1 + (p_accuracy >= 0.85)::int + (p_accuracy >= 0.95)::int end;

  insert into public.attempts (user_id, task_id, client_attempt_id, score, stars, accuracy, duration_s, notes_played)
  values (uid, p_task_id, p_client_attempt_id, p_score, v_stars, p_accuracy, p_duration_s, greatest(p_notes, 0))
  on conflict (user_id, client_attempt_id) do nothing
  returning id into v_new;

  if v_new is not null and v_stars > 0 then
    insert into public.task_progress as tp (user_id, task_id, best_stars, best_accuracy)
    values (uid, p_task_id, v_stars, p_accuracy)
    on conflict (user_id, task_id) do update
      set best_stars = greatest(tp.best_stars, excluded.best_stars),
          best_accuracy = greatest(tp.best_accuracy, excluded.best_accuracy);
  end if;
  return query select v_stars, v_stars > 0;
end $$;

-- Per-mission progress WITHOUT leaking locked content (counts only).
create function public.mission_progress()
returns table (mission_id uuid, tasks_total int, tasks_done int, stars int)
language sql stable security definer set search_path = public as $$
  select m.id, count(t.id)::int, count(tp.task_id)::int, coalesce(sum(tp.best_stars), 0)::int
  from public.missions m
  left join public.tasks t on t.mission_id = m.id
  left join public.task_progress tp on tp.task_id = t.id and tp.user_id = auth.uid()
  group by m.id
$$;

create function public.my_entitlement()
returns table (tier text, status text, current_period_end timestamptz, auto_renewing boolean, seconds_left int)
language sql stable security definer set search_path = public as $$
  select s.tier, s.status, s.current_period_end, s.auto_renewing, public.seconds_left_today()
  from (select 1) x
  left join lateral (
    select * from public.subscriptions
    where user_id = auth.uid()
      and status in ('trialing','active','grace','canceled')
      and current_period_end > now()
    order by current_period_end desc limit 1
  ) s on true
$$;

-- ───────────── row level security ─────────────

alter table public.profiles           enable row level security;
alter table public.levels             enable row level security;
alter table public.missions           enable row level security;
alter table public.songs              enable row level security;
alter table public.song_charts        enable row level security;
alter table public.tasks              enable row level security;
alter table public.attempts           enable row level security;
alter table public.task_progress      enable row level security;
alter table public.daily_usage        enable row level security;
alter table public.subscriptions      enable row level security;
alter table public.play_notifications enable row level security;   -- no policy: service role only

create policy own_profile_read   on public.profiles for select to authenticated using (id = auth.uid());
create policy own_profile_update on public.profiles for update to authenticated
  using (id = auth.uid()) with check (id = auth.uid());

create policy levels_read   on public.levels   for select to authenticated using (true);
create policy missions_read on public.missions for select to authenticated using (true);   -- lock badges need the list
create policy songs_read    on public.songs    for select to authenticated using (true);

-- Locked content is hidden by the database, not by the app.
create policy tasks_unlocked on public.tasks for select to authenticated using (
  exists (select 1 from public.missions m
          where m.id = tasks.mission_id and (m.is_free or public.has_premium()))
);
create policy charts_unlocked on public.song_charts for select to authenticated using (
  exists (select 1 from public.songs s
          where s.id = song_charts.song_id
            and (public.has_premium() or (not s.is_premium and public.seconds_left_today() > 0)))
);

create policy own_attempts      on public.attempts      for select to authenticated using (user_id = auth.uid());
create policy own_progress      on public.task_progress for select to authenticated using (user_id = auth.uid());
create policy own_usage         on public.daily_usage   for select to authenticated using (user_id = auth.uid());
create policy own_subscriptions on public.subscriptions for select to authenticated using (user_id = auth.uid());

-- ───────────── privileges ─────────────

revoke all on all tables in schema public from anon, authenticated;
grant select on public.profiles, public.levels, public.missions, public.songs, public.song_charts,
  public.tasks, public.attempts, public.task_progress, public.daily_usage, public.subscriptions
  to authenticated;
-- clients may edit only these profile columns (never last_report_sent_on)
grant update (display_name, instrument, skill_level, guitar_type, tuning, timezone, audio_latency_ms)
  on public.profiles to authenticated;

revoke execute on function public._has_premium(uuid), public._local_today(uuid),
  public._can_access_task(uuid, uuid) from public, anon, authenticated;
revoke execute on function public.add_play_time(int, int), public.submit_attempt(uuid, uuid, int, numeric, int, int),
  public.mission_progress(), public.my_entitlement(), public.has_premium(), public.seconds_left_today()
  from public, anon;
grant execute on function public.add_play_time(int, int), public.submit_attempt(uuid, uuid, int, numeric, int, int),
  public.mission_progress(), public.my_entitlement(), public.has_premium(), public.seconds_left_today()
  to authenticated;
