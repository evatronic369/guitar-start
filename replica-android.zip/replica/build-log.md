# Build log

2026-10-27 | audio spike + vertical slice | PARTIAL, NOT COMPILED, NOT RUN
- Written: Yin.kt, MicPitchSource.kt, PlaySession and star rule, FakeRepository (1 level, 2 missions, 3 tasks), PathScreen, PlayScreen, ResultScreen, 5 unit tests.
- Not done: nothing here was compiled or run (no Android SDK or network in this workspace). Expect to fix small build errors on first sync; Gradle/AGP/Kotlin/Compose versions are from memory.
- Missing: S01 sign-up, S02, S04, S12 tuner, videos, song search, progress screen. Progress is in memory only. Wait-mode play (no scrolling lane, no timing). Design tokens are placeholders.
- Harder than it looks: chords, timed play and latency calibration. Left for after the single-note spike works on real phones.

2026-10-27 | APK build route | NOT RUN
- Added android/.github/workflows/build-apk.yml (GitHub Actions: unit tests, then assembleDebug, uploads app-debug.apk). Unverified: first run may need small fixes.
