-- replica/schema.sql  (ALL-FREE version: no subscriptions, no paywall, no daily cap)
-- The paid version is kept in schema-paid.sql in case you add monetisation later.
-- Postgres on Supabase. Clients read through row level security; they write only through the rpc functions below.
-- Deviations from "id uuid default gen_random_uuid()": profiles.id = auth.users.id; task_progress and daily_usage use composite keys.
-- NOT run against a live Postgres yet (none in this workspace).

create function public.set_updated_at() returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  skill_level text check (skill_level in ('beginner','some_experience','advanced')),
  guitar_type text check (guitar_type in ('acoustic','electric')),
  tuning text not null default 'EADGBE',
  timezone text not null default 'UTC',
  audio_latency_ms int not null default 0 check (audio_latency_ms between 0 and 1000),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.levels (
  id uuid primary key default gen_random_uuid(),
  number smallint not null unique check (number between 1 and 10),
  title text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.missions (
  id uuid primary key default gen_random_uuid(),
  level_id uuid not null references public.levels(id) on delete restrict,
  theme text not null check (theme in ('melody','chords','knowledge')),
  title text not null,
  position smallint not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (level_id, theme, position)
);
create index on public.missions (level_id);

create table public.songs (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  license text not null check (license in ('original','public_domain','licensed')),
  difficulty smallint not null check (difficulty between 1 and 10),
  chart jsonb not null,            -- wait mode: array of midi numbers in order. Timed mode later adds t_ms per note.
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index on public.songs (difficulty);

create table public.tasks (
  id uuid primary key default gen_random_uuid(),
  mission_id uuid not null references public.missions(id) on delete cascade,
  position smallint not null,
  type text not null check (type in ('song','video','trainer')),
  title text not null,
  song_id uuid references public.songs(id) on delete restrict,
  video_path text,
  trainer_config jsonb,
  pass_accuracy numeric(3,2) not null default 0.70 check (pass_accuracy between 0 and 1),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (mission_id, position),
  constraint task_shape check (
    (type = 'song' and song_id is not null) or
    (type = 'video' and video_path is not null) or
    (type = 'trainer' and trainer_config is not null))
);
create index on public.tasks (song_id);

create table public.attempts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  task_id uuid not null references public.tasks(id) on delete cascade,
  client_attempt_id uuid not null,
  stars smallint not null check (stars between 0 and 3),
  accuracy numeric(5,4) not null check (accuracy between 0 and 1),
  duration_s int not null check (duration_s between 0 and 3600),
  played_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (user_id, client_attempt_id)
);
create index on public.attempts (user_id, played_at desc);
create index on public.attempts (task_id);

create table public.task_progress (
  user_id uuid not null references public.profiles(id) on delete cascade,
  task_id uuid not null references public.tasks(id) on delete cascade,
  best_stars smallint not null check (best_stars between 0 and 3),
  best_accuracy numeric(5,4) not null check (best_accuracy between 0 and 1),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  primary key (user_id, task_id)
);
create index on public.task_progress (task_id);

create table public.daily_usage (       -- stats and streak only; nothing is limited
  user_id uuid not null references public.profiles(id) on delete cascade,
  usage_date date not null,             -- the user's local date
  play_seconds int not null default 0 check (play_seconds >= 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  primary key (user_id, usage_date)
);

do $$ declare t text; begin
  foreach t in array array['profiles','levels','missions','songs','tasks','attempts','task_progress','daily_usage']
  loop execute format('create trigger set_updated_at before update on public.%I for each row execute function public.set_updated_at()', t);
  end loop; end $$;

create function public.handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin insert into public.profiles (id) values (new.id) on conflict do nothing; return new; end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

create function public.validate_timezone() returns trigger language plpgsql as $$
begin
  if not exists (select 1 from pg_timezone_names where name = new.timezone) then
    raise exception 'invalid timezone: %', new.timezone; end if;
  return new; end $$;
create trigger validate_timezone before insert or update of timezone on public.profiles
  for each row execute function public.validate_timezone();

-- RPCs (the only write path)
create function public.add_play_time(p_seconds int) returns void
language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid();
begin
  if uid is null then raise exception 'not authenticated' using errcode = '28000'; end if;
  if p_seconds < 0 or p_seconds > 60 then raise exception 'bad seconds'; end if;
  insert into public.daily_usage as u (user_id, usage_date, play_seconds)
  values (uid, (now() at time zone (select timezone from public.profiles where id = uid))::date, p_seconds)
  on conflict (user_id, usage_date) do update set play_seconds = u.play_seconds + excluded.play_seconds;
end $$;

-- Same star rule as the app's fake data layer: below pass = 0, else 1 + (>= 0.85) + (>= 0.95).
create function public.submit_attempt(p_task_id uuid, p_client_attempt_id uuid, p_accuracy numeric, p_duration_s int)
returns smallint language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); v_pass numeric; v_stars smallint; v_new uuid;
begin
  if uid is null then raise exception 'not authenticated' using errcode = '28000'; end if;
  select pass_accuracy into v_pass from public.tasks where id = p_task_id;
  if v_pass is null then raise exception 'unknown task'; end if;
  v_stars := (case when p_accuracy < v_pass then 0 else 1 + (p_accuracy >= 0.85)::int + (p_accuracy >= 0.95)::int end)::smallint;
  insert into public.attempts (user_id, task_id, client_attempt_id, stars, accuracy, duration_s)
  values (uid, p_task_id, p_client_attempt_id, v_stars, p_accuracy, p_duration_s)
  on conflict (user_id, client_attempt_id) do nothing returning id into v_new;
  if v_new is not null and v_stars > 0 then
    insert into public.task_progress as tp (user_id, task_id, best_stars, best_accuracy)
    values (uid, p_task_id, v_stars, p_accuracy)
    on conflict (user_id, task_id) do update
      set best_stars = greatest(tp.best_stars, excluded.best_stars),
          best_accuracy = greatest(tp.best_accuracy, excluded.best_accuracy);
  end if;
  return v_stars;
end $$;

create function public.mission_progress() returns table (mission_id uuid, tasks_total int, tasks_done int, stars int)
language sql stable security definer set search_path = public as $$
  select m.id, count(t.id)::int, count(tp.task_id)::int, coalesce(sum(tp.best_stars), 0)::int
  from public.missions m
  left join public.tasks t on t.mission_id = m.id
  left join public.task_progress tp on tp.task_id = t.id and tp.user_id = auth.uid()
  group by m.id $$;

-- row level security
alter table public.profiles enable row level security;
alter table public.levels enable row level security;
alter table public.missions enable row level security;
alter table public.songs enable row level security;
alter table public.tasks enable row level security;
alter table public.attempts enable row level security;
alter table public.task_progress enable row level security;
alter table public.daily_usage enable row level security;

create policy own_profile_read   on public.profiles for select to authenticated using (id = auth.uid());
create policy own_profile_update on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());
create policy content_levels   on public.levels   for select to authenticated using (true);
create policy content_missions on public.missions for select to authenticated using (true);
create policy content_songs    on public.songs    for select to authenticated using (true);
create policy content_tasks    on public.tasks    for select to authenticated using (true);
create policy own_attempts on public.attempts      for select to authenticated using (user_id = auth.uid());
create policy own_progress on public.task_progress for select to authenticated using (user_id = auth.uid());
create policy own_usage    on public.daily_usage   for select to authenticated using (user_id = auth.uid());

revoke all on all tables in schema public from anon, authenticated;
grant select on all tables in schema public to authenticated;
grant update (display_name, skill_level, guitar_type, tuning, timezone, audio_latency_ms) on public.profiles to authenticated;
revoke execute on function public.add_play_time(int), public.submit_attempt(uuid, uuid, numeric, int), public.mission_progress() from public, anon;
grant execute on function public.add_play_time(int), public.submit_attempt(uuid, uuid, numeric, int), public.mission_progress() to authenticated;
