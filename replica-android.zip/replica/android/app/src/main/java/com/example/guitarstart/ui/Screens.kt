package com.example.guitarstart.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.guitarstart.audio.MicPitchSource
import com.example.guitarstart.audio.Pitch
import com.example.guitarstart.data.*

@Composable
fun PathScreen(repo: Repository, version: Int, onOpen: (Task) -> Unit) {
    var levels by remember { mutableStateOf<List<Level>?>(null) }
    var best by remember { mutableStateOf<Map<String, Int>>(emptyMap()) }
    LaunchedEffect(version) {
        val l = repo.levels(); levels = l
        best = l.flatMap { it.missions }.flatMap { it.tasks }.associate { it.id to repo.bestStars(it.id) }
    }
    val ls = levels
    if (ls == null) { Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }; return }
    LazyColumn(Modifier.fillMaxSize().padding(Space.m), verticalArrangement = Arrangement.spacedBy(Space.m)) {
        for (level in ls) {
            item { Text("Level ${level.number}: ${level.title}", style = MaterialTheme.typography.headlineSmall) }
            for (mission in level.missions) item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(Space.m), verticalArrangement = Arrangement.spacedBy(Space.s)) {
                        Text(mission.title, style = MaterialTheme.typography.titleMedium)
                        for (task in mission.tasks) OutlinedButton(onClick = { onOpen(task) }, Modifier.fillMaxWidth()) {
                            Text(task.title, Modifier.weight(1f))
                            Text("★".repeat(best[task.id] ?: 0) + "☆".repeat(3 - (best[task.id] ?: 0)))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PlayScreen(task: Task, onDone: (accuracy: Float, durationS: Int) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) }
    val ask = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    if (!granted) {
        Column(Modifier.fillMaxSize().padding(Space.l), Arrangement.Center, Alignment.CenterHorizontally) {
            Text("Guitar Start needs the microphone to hear which note you play. Nothing is recorded or stored.", textAlign = TextAlign.Center)
            Spacer(Modifier.height(Space.m))
            Button(onClick = { ask.launch(Manifest.permission.RECORD_AUDIO) }) { Text("Allow microphone") }
            TextButton(onClick = onBack) { Text("Back") }
        }
        return
    }
    val session = remember(task.id) { PlaySession(task.notes) }
    var heard by remember { mutableStateOf<Int?>(null) }
    val startedAt = remember(task.id) { System.currentTimeMillis() }
    LaunchedEffect(task.id) {
        var reported = false                       // the mic keeps emitting until the screen leaves; report once
        MicPitchSource().pitches().collect { hz ->
            val midi = Pitch.toMidi(hz); heard = midi
            session.onPitch(midi, System.currentTimeMillis())
            if (session.finished && !reported) {
                reported = true
                onDone(session.accuracy, ((System.currentTimeMillis() - startedAt) / 1000).toInt())
            }
        }
    }
    Column(Modifier.fillMaxSize().padding(Space.l), Arrangement.Center, Alignment.CenterHorizontally) {
        Text("Note ${minOf(session.index + 1, task.notes.size)} of ${task.notes.size}", style = MaterialTheme.typography.labelLarge)
        Spacer(Modifier.height(Space.m))
        Text("Play this note", style = MaterialTheme.typography.titleMedium)
        Text(session.target?.let { Pitch.name(it) } ?: "", fontSize = 96.sp, color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(Space.m))
        val h = heard
        Text(
            when {
                h == null -> "Listening…"
                h == session.target -> "That's it, hold it"
                else -> "I hear ${Pitch.name(h)}"
            }, style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(Space.l))
        TextButton(onClick = onBack) { Text("Stop") }
    }
}

@Composable
fun ResultScreen(stars: Int, accuracy: Float, onRetry: () -> Unit, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(Space.l), Arrangement.Center, Alignment.CenterHorizontally) {
        Text("★".repeat(stars) + "☆".repeat(3 - stars), fontSize = 48.sp, color = MaterialTheme.colorScheme.secondary)
        Spacer(Modifier.height(Space.s))
        Text("${(accuracy * 100).toInt()}% of notes", style = MaterialTheme.typography.titleLarge)
        Text(if (stars == 0) "Not quite yet. Try it again." else "Nice work.")
        Spacer(Modifier.height(Space.l))
        Button(onClick = onRetry) { Text("Play again") }
        TextButton(onClick = onBack) { Text("Back to the path") }
    }
}
