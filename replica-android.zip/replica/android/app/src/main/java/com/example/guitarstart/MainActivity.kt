package com.example.guitarstart

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.example.guitarstart.data.*
import com.example.guitarstart.ui.*
import kotlinx.coroutines.launch
import java.util.UUID

private sealed interface Screen {
    data object Path : Screen
    data class Play(val task: Task, val run: Int) : Screen
    data class Result(val task: Task, val stars: Int, val accuracy: Float) : Screen
}

class MainActivity : ComponentActivity() {
    private val repo: Repository = FakeRepository()   // swap for the Supabase repository at /replica-backend

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AppTheme {
                Surface(Modifier.fillMaxSize()) {
                    var screen by remember { mutableStateOf<Screen>(Screen.Path) }
                    var version by remember { mutableIntStateOf(0) }
                    val scope = rememberCoroutineScope()
                    when (val s = screen) {
                        Screen.Path -> PathScreen(repo, version) { screen = Screen.Play(it, 0) }
                        is Screen.Play -> key(s.run) {
                            PlayScreen(s.task, onBack = { screen = Screen.Path }, onDone = { acc, secs ->
                                scope.launch {
                                    val stars = repo.submitAttempt(s.task.id, UUID.randomUUID().toString(), acc, secs)
                                    version++
                                    screen = Screen.Result(s.task, stars, acc)
                                }
                            })
                        }
                        is Screen.Result -> ResultScreen(s.stars, s.accuracy,
                            onRetry = { screen = Screen.Play(s.task, 1) }, onBack = { screen = Screen.Path })
                    }
                }
            }
        }
    }
}
