package com.example.guitarstart.data

/** In-memory seed data. Progress is lost when the app closes (the real data layer fixes that). Open-string MIDI: E2=40 A2=45 D3=50 G3=55 B3=59 E4=64. */
class FakeRepository : Repository {
    private val stars = mutableMapOf<String, Int>()
    private val seen = mutableSetOf<String>()

    private val data = listOf(
        Level(1, "Getting started", listOf(
            Mission("m1", "Meet the strings", listOf(
                Task("t1", "All six strings, low to high", listOf(40, 45, 50, 55, 59, 64)),
                Task("t2", "Up and back", listOf(64, 59, 55, 50, 55, 59, 64)))),
            Mission("m2", "A first pattern", listOf(
                Task("t3", "Three strings, repeated", listOf(59, 55, 50, 55, 59, 55, 50, 55)))))))

    override suspend fun levels() = data
    override suspend fun bestStars(taskId: String) = stars[taskId] ?: 0
    override suspend fun submitAttempt(taskId: String, clientAttemptId: String, accuracy: Float, durationS: Int): Int {
        val s = Stars.of(accuracy)
        if (seen.add(clientAttemptId)) stars[taskId] = maxOf(stars[taskId] ?: 0, s)   // retries with the same id do nothing
        return s
    }
}
