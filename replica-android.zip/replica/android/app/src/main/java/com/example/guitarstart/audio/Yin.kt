package com.example.guitarstart.audio

import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** YIN pitch detection (de Cheveigne and Kawahara, 2002), written from the published description. */
class Yin(private val sampleRate: Int, val frameSize: Int = 2048, private val threshold: Float = 0.15f) {
    private val half = frameSize / 2
    private val d = FloatArray(half)

    /** Frequency in Hz, or -1f when the frame is silent or has no clear pitch. */
    fun detect(buf: FloatArray): Float {
        var energy = 0f
        for (i in 0 until frameSize) energy += buf[i] * buf[i]
        if (sqrt(energy / frameSize) < 0.01f) return -1f           // too quiet

        for (tau in 0 until half) {                                  // 1. difference function
            var sum = 0f
            for (i in 0 until half) { val x = buf[i] - buf[i + tau]; sum += x * x }
            d[tau] = sum
        }
        d[0] = 1f                                                    // 2. cumulative mean normalised
        var running = 0f
        for (tau in 1 until half) {
            running += d[tau]
            d[tau] = if (running == 0f) 1f else d[tau] * tau / running
        }
        var tau = 2                                                  // 3. first dip under the threshold
        while (tau < half) {
            if (d[tau] < threshold) { while (tau + 1 < half && d[tau + 1] < d[tau]) tau++; break }
            tau++
        }
        if (tau >= half) return -1f
        if (tau + 1 >= half) return sampleRate / tau.toFloat()
        val s0 = d[tau - 1]; val s1 = d[tau]; val s2 = d[tau + 1]    // 4. parabolic interpolation
        val denom = 2f * (2f * s1 - s2 - s0)
        val shift = if (denom == 0f) 0f else (s2 - s0) / denom
        return sampleRate / (tau + shift)
    }
}

object Pitch {
    private val names = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
    /** Nearest MIDI note, or null if no pitch or more than 40 cents off any note. */
    fun toMidi(hz: Float): Int? {
        if (hz <= 0f) return null
        val exact = 69.0 + 12.0 * ln(hz / 440.0) / ln(2.0)
        val nearest = exact.roundToInt()
        return if (abs(exact - nearest) <= 0.4) nearest else null
    }
    fun name(midi: Int) = names[((midi % 12) + 12) % 12] + (midi / 12 - 1)
}
