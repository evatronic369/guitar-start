package com.example.guitarstart.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/** Placeholder tokens. /replica-design has not run; it will replace these values. Screens use only these names. */
object Space { val s = 8.dp; val m = 16.dp; val l = 24.dp }
private val Light = lightColorScheme(primary = Color(0xFF2F5D50), secondary = Color(0xFFB8741A))
private val Dark = darkColorScheme(primary = Color(0xFF8FC7B5), secondary = Color(0xFFE0A458))

@Composable fun AppTheme(content: @Composable () -> Unit) =
    MaterialTheme(colorScheme = if (isSystemInDarkTheme()) Dark else Light, content = content)
