package com.example.guitarstart.audio

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.isActive

/** Emits a frequency in Hz (or -1f for none) about every 23 ms. Caller must hold RECORD_AUDIO. */
class MicPitchSource(private val sampleRate: Int = 44100) {
    private val frame = 2048
    private val hop = 1024

    @SuppressLint("MissingPermission")
    fun pitches(): Flow<Float> = flow {
        val minBuf = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val size = maxOf(minBuf, frame * 4)
        // UNPROCESSED skips the phone's noise suppression; not every phone supports it, so fall back to MIC.
        var rec = AudioRecord(MediaRecorder.AudioSource.UNPROCESSED, sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, size)
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            rec = AudioRecord(MediaRecorder.AudioSource.MIC, sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, size)
        }
        val yin = Yin(sampleRate, frame)
        val window = FloatArray(frame)
        val chunk = ShortArray(hop)
        rec.startRecording()
        try {
            while (currentCoroutineContext().isActive) {
                val n = rec.read(chunk, 0, hop)
                if (n < 0) break
                if (n == 0) continue
                System.arraycopy(window, n, window, 0, frame - n)
                for (i in 0 until n) window[frame - n + i] = chunk[i] / 32768f
                emit(yin.detect(window))
            }
        } finally {
            rec.stop(); rec.release()
        }
    }.flowOn(Dispatchers.IO)
}
