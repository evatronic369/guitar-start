package com.example.guitarstart.data

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue

data class Task(val id: String, val title: String, val notes: List<Int>)   // notes = MIDI numbers, played in order
data class Mission(val id: String, val title: String, val tasks: List<Task>)
data class Level(val number: Int, val title: String, val missions: List<Mission>)

/** The data layer. FakeRepository implements it now; the Supabase one replaces it later with no screen changes. */
interface Repository {
    suspend fun levels(): List<Level>
    suspend fun bestStars(taskId: String): Int
    /** Same rule as submit_attempt in schema.sql. Returns stars 0..3. */
    suspend fun submitAttempt(taskId: String, clientAttemptId: String, accuracy: Float, durationS: Int): Int
}

object Stars {
    const val PASS = 0.70f
    fun of(accuracy: Float) = if (accuracy < PASS) 0 else 1 + (if (accuracy >= 0.85f) 1 else 0) + (if (accuracy >= 0.95f) 1 else 0)
}

/** One run through a task: wait for each target note, hold it briefly, or give up on it after a timeout. */
class PlaySession(private val targets: List<Int>, private val holdMs: Long = 200, private val timeoutMs: Long = 8000) {
    var index by mutableIntStateOf(0); private set
    var hits by mutableIntStateOf(0); private set
    val finished get() = index >= targets.size
    val target get() = targets.getOrNull(index)
    val accuracy get() = if (targets.isEmpty()) 0f else hits.toFloat() / targets.size
    private var noteStart = -1L
    private var heldSince = -1L

    fun onPitch(midi: Int?, nowMs: Long) {
        if (finished) return
        if (noteStart < 0) noteStart = nowMs
        if (midi != null && midi == targets[index]) {
            if (heldSince < 0) heldSince = nowMs
            if (nowMs - heldSince >= holdMs) { hits++; advance(); return }
        } else heldSince = -1
        if (nowMs - noteStart >= timeoutMs) advance()
    }
    private fun advance() { index++; noteStart = -1; heldSince = -1 }
}
