package com.example.guitarstart

import com.example.guitarstart.audio.Pitch
import com.example.guitarstart.audio.Yin
import com.example.guitarstart.data.PlaySession
import com.example.guitarstart.data.Stars
import org.junit.Assert.*
import org.junit.Test
import kotlin.math.PI
import kotlin.math.sin

class YinTest {
    private fun sine(hz: Float, rate: Int = 44100, n: Int = 2048) = FloatArray(n) { (0.5 * sin(2 * PI * hz * it / rate)).toFloat() }

    @Test fun findsOpenStrings() {
        val yin = Yin(44100)
        for ((hz, midi) in listOf(82.41f to 40, 110f to 45, 146.83f to 50, 196f to 55, 246.94f to 59, 329.63f to 64)) {
            val got = yin.detect(sine(hz))
            assertEquals("freq for midi $midi", hz, got, hz * 0.01f)
            assertEquals(midi, Pitch.toMidi(got))
        }
    }
    @Test fun silenceGivesNothing() = assertEquals(-1f, Yin(44100).detect(FloatArray(2048)), 0f)
    @Test fun starRule() { assertEquals(0, Stars.of(0.6f)); assertEquals(1, Stars.of(0.7f)); assertEquals(2, Stars.of(0.85f)); assertEquals(3, Stars.of(0.95f)) }
    @Test fun sessionAdvancesAfterHold() {
        val s = PlaySession(listOf(40, 45)); var t = 0L
        repeat(15) { s.onPitch(40, t); t += 23 }
        assertEquals(1, s.hits); assertEquals(1, s.index)
    }
    @Test fun sessionTimesOut() {
        val s = PlaySession(listOf(40), timeoutMs = 1000); var t = 0L
        repeat(60) { s.onPitch(null, t); t += 23 }
        assertTrue(s.finished); assertEquals(0, s.hits)
    }
}
